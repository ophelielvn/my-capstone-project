
# coding: utf-8

# # Capstone 2: Biodiversity Project

# # Introduction
# You are a biodiversity analyst working for the National Parks Service.  You're going to help them analyze some data about species at various national parks.
# 
# Note: The data that you'll be working with for this project is *inspired* by real data, but is mostly fictional.

# # Step 1
# Import the modules that you'll be using in this assignment:
# - `from matplotlib import pyplot as plt`
# - `import pandas as pd`

# In[1]:


from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
# we will use numpy later when performing significance tests


# # Step 2
# You have been given two CSV files. `species_info.csv` with data about different species in our National Parks, including:
# - The scientific name of each species
# - The common names of each species
# - The species conservation status
# 
# Load the dataset and inspect it:
# - Load `species_info.csv` into a DataFrame called `species`

# In[2]:


# Load data from 'species_info.csv'
species = pd.read_csv('species_info.csv')


# Inspect each DataFrame using `.head()`.

# In[3]:


species.head()


# # Step 3
# Let's start by learning a bit more about our data.  Answer each of the following questions.

# How many different species are in the `species` DataFrame?

# In[4]:


# Count the number of unique 'scientific_names'
species.scientific_name.nunique()


# What are the different values of `category` in `species`?

# In[5]:


# Return the different categories of species
species.category.unique()


# What are the different values of `conservation_status`?

# In[6]:


# Return the different conservation statuses
species.conservation_status.unique()


# ### Step 3: Further look into the data

# In[7]:


# Create a new column to add the kingdom (plant / animal) and return the number of species by kingdom
species['kingdom'] = species.category.apply(lambda x: "Plant" if "Plant" in x else "Animal")
species.groupby('kingdom').scientific_name.nunique()


# In[8]:


# Return the number of species by category and display the kingdom
species_by_category = species.groupby(['kingdom', 'category']).scientific_name.nunique().reset_index()
species_by_category.columns = ['kingdom', 'category', 'number_species']
species_by_category


# In[9]:


# Create a bar chart to display the number of species by category and by kingdom
species_colors = ['gold', 'darkorange', 'orangered', 'sienna', 'saddlebrown', 'limegreen', 'forestgreen']

# plot the horizontal bar chart
plt.figure(figsize=(9, 6))
ax = plt.subplot()
plt.barh(range(len(species_by_category)), species_by_category.number_species.values, align='center', color=species_colors)

# add some text for labels, title and ticks
ax.set_xlim([0, 5000])
ax.set_yticks(range(len(species_by_category)))
ax.set_yticklabels(species_by_category.category.values)
plt.xlabel('Number of Species')
plt.title('Number of Species by Categories')

# attach a text label next to each bar displaying its length
for i in species_by_category.index:
    ax.text(species_by_category.at[i, 'number_species']+300, i, species_by_category.at[i, 'number_species'], fontsize=11, ha='center', va='center')

# attach a text with the sum of species by kingdom
plant_kingdom = 0
animal_kingdom = 0
for i in species_by_category.index:
    if 'Plant' in species_by_category.at[i, 'kingdom']:
        plant_kingdom = plant_kingdom + species_by_category.at[i, 'number_species']
    else:
        animal_kingdom = animal_kingdom + species_by_category.at[i, 'number_species']
ax.text(1000, 5.2, "Plants: %d species" % (plant_kingdom), fontsize=18, color='darkgreen' , ha='left', va='center')
ax.text(1000, 2.1, "Animals: %d species" % (animal_kingdom), fontsize=18, color='brown' , ha='left', va='center')

plt.show()


# # Step 4
# Let's start doing some analysis!
# 
# The column `conservation_status` has several possible values:
# - `Species of Concern`: declining or appear to be in need of conservation
# - `Threatened`: vulnerable to endangerment in the near future
# - `Endangered`: seriously at risk of extinction
# - `In Recovery`: formerly `Endangered`, but currnetly neither in danger of extinction throughout all or a significant portion of its range
# 
# We'd like to count up how many species meet each of these criteria.  Use `groupby` to count how many `scientific_name` meet each of these criteria.

# In[10]:


# Count the number of species for each conservation status
endangered_species = species.groupby('conservation_status').scientific_name.nunique().reset_index()
# we will use endangered_species later to create a pie chart


# As we saw before, there are far more than 200 species in the `species` table.  Clearly, only a small number of them are categorized as needing some sort of protection.  The rest have `conservation_status` equal to `None`.  Because `groupby` does not include `None`, we will need to fill in the null values.  We can do this using `.fillna`.  We pass in however we want to fill in our `None` values as an argument.
# 
# Paste the following code and run it to see replace `None` with `No Intervention`:
# ```python
# species.fillna('No Intervention', inplace=True)
# ```

# In[11]:


# Replace the 'None' status by 'No intervention' to return the empty values in the previous table
species.fillna('No Intervention', inplace=True)


# Great! Now run the same `groupby` as before to see how many species require `No Protection`.

# In[12]:


# Count the number of species for each conservation status in adding the 'No intervention' status
species.groupby('conservation_status').scientific_name.nunique().reset_index()


# Let's use `plt.bar` to create a bar chart.  First, let's sort the columns by how many species are in each categories.  We can do this using `.sort_values`.  We use the the keyword `by` to indicate which column we want to sort by.
# 
# Paste the following code and run it to create a new DataFrame called `protection_counts`, which is sorted by `scientific_name`:
# ```python
# protection_counts = species.groupby('conservation_status')\
#     .scientific_name.count().reset_index()\
#     .sort_values(by='scientific_name')
# ```

# In[13]:


# Create firstly a new DataFrame in order to then create a chart
protection_counts = species.groupby('conservation_status')    .scientific_name.nunique().reset_index()    .sort_values(by='scientific_name')


# Now let's create a bar chart!
# 1. Start by creating a wide figure with `figsize=(10, 4)`
# 1. Start by creating an axes object called `ax` using `plt.subplot`.
# 2. Create a bar chart whose heights are equal to `scientific_name` column of `protection_counts`.
# 3. Create an x-tick for each of the bars.
# 4. Label each x-tick with the label from `conservation_status` in `protection_counts`
# 5. Label the y-axis `Number of Species`
# 6. Title the graph `Conservation Status by Species`
# 7. Plot the grap using `plt.show()`

# In[14]:


# Create a chart to display the number of species by conservation status (following the instructions)
plt.figure(figsize=(10, 4))
ax = plt.subplot()
plt.bar(range(len(protection_counts)), protection_counts.scientific_name.values)

# add some text for labels, title and ticks
ax.set_xticks(range(len(protection_counts)))
ax.set_xticklabels(protection_counts.conservation_status.values)
plt.ylabel('Number of Species')
plt.title('Conservation Status by Species')

plt.show()


# ### Step 4: Further analysis and visualization

# In[15]:


# Create a pivot table to count the number of plant and animal species by conservation status
conservation_by_kingdom = species.groupby(['kingdom', 'conservation_status']).scientific_name.nunique().reset_index()
conservation_pivot = conservation_by_kingdom.pivot(columns='kingdom',
                                   index='conservation_status',
                                   values='scientific_name').reset_index()
conservation_pivot


# In[16]:


# Create a visually different bar chart by displaying species from the most endangered status to the least endangered status
new_index = [0, 1, 4, 3, 2]
bar_colors = ["r", "coral", "orange", "gold", "lightgrey"]
new_protection_counts = protection_counts.reindex(new_index).reset_index()

plt.figure(figsize=(5, 6))
ax = plt.subplot()
plt.bar(range(len(new_protection_counts)), new_protection_counts.scientific_name.values, color=bar_colors)

# add some text for labels, title and ticks
ax.set_xticks(range(len(new_protection_counts)))
ax.set_xticklabels(new_protection_counts.conservation_status.values, rotation=45)
plt.ylabel('Number of Species')
plt.title('Conservation Status by Species')

# attach a text label above each bar displaying its height
for i in new_protection_counts.index:
    ax.text(i, new_protection_counts.at[i, 'scientific_name']+150, new_protection_counts.at[i, 'scientific_name'], fontsize=11, ha='center', va='center')

plt.show()


# In[17]:


# Create a pie chart focusing on the most endangered status only to give more detailled information
pie_colors = ["r", "coral", "gold", "orange"]
pie_explode = (0.2, 0.1, 0, 0.1)

fig, ax = plt.subplots()
ax.pie(endangered_species.scientific_name.values,         explode=pie_explode,         labels=endangered_species.scientific_name.values,         labeldistance=1.10,         colors=pie_colors,         shadow=True)
ax.axis('equal')
ax.legend(endangered_species.conservation_status.values, loc=3)
plt.title("Endangered Status by Species")

plt.show()


# # Step 5
# Are certain types of species more likely to be endangered?

# Let's create a new column in `species` called `is_protected`, which is `True` if `conservation_status` is not equal to `No Intervention`, and `False` otherwise.

# In[18]:


# Add a new column 'is_protected'
species['is_protected'] = species.conservation_status != "No Intervention"


# Let's group by *both* `category` and `is_protected`.  Save your results to `category_counts`.

# In[19]:


# Create a new DataFrame to group data by 'category' and 'is_protected'
category_counts = species.groupby(['category', 'is_protected']).scientific_name.nunique().reset_index()


# Examine `category_count` using `head()`.

# In[20]:


category_counts.head()


# It's going to be easier to view this data if we pivot it.  Using `pivot`, rearange `category_counts` so that:
# - `columns` is `conservation_status`
# - `index` is `category`
# - `values` is `scientific_name`
# 
# Save your pivoted data to `category_pivot`. Remember to `reset_index()` at the end.

# In[21]:


# Create a pivot table with the previsouly new organised information
category_pivot = category_counts.pivot(columns='is_protected',
                                       index='category', 
                                       values='scientific_name').reset_index()


# Examine `category_pivot`.

# In[22]:


category_pivot


# Use the `.columns` property to  rename the categories `True` and `False` to something more description:
# - Leave `category` as `category`
# - Rename `False` to `not_protected`
# - Rename `True` to `protected`

# In[23]:


# Rename columns to improve readibility
category_pivot.columns = ['category', 'not_protected', 'protected']


# Let's create a new column of `category_pivot` called `percent_protected`, which is equal to `protected` (the number of species that are protected) divided by `protected` plus `not_protected` (the total number of species).

# In[24]:


# Add a new column to the pivtot table to display percentages of protected species
category_pivot['percent_protected'] = category_pivot.protected /                                       (category_pivot.protected + category_pivot.not_protected)


# Examine `category_pivot`.

# In[25]:


category_pivot


# ### Step 5: Further visualization

# In[26]:


# Create a pie chart to visualize the distribution of protected species by category
pie_colors = ['gold', 'darkorange', 'orangered', 'sienna', 'limegreen', 'saddlebrown', 'forestgreen']

fig = plt.figure(figsize=[9, 4])
plt.pie(category_pivot.protected.values, labels=category_pivot.protected.values, colors=pie_colors, startangle=90, counterclock=False)
plt.axis('equal')
plt.title('Number of Protected Species')
plt.legend(category_pivot.category.values, loc=4)

plt.show()


# It looks like species in category `Mammal` are more likely to be endangered than species in `Bird`.  We're going to do a significance test to see if this statement is true.  Before you do the significance test, consider the following questions:
# - Is the data numerical or categorical?
# - How many pieces of data are you comparing?

# In[27]:


# The data for this test is categorical because it represents characteristic of species as the conservation status.

# We are going to compare two variables `Mammal` and `Bird` to determine whether a relationship between the two categorical 
# variables in the sample is likely to reflect a real association between these two variables in the population.


# Based on those answers, you should choose to do a *chi squared test*.  In order to run a chi squared test, we'll need to create a contingency table.  Our contingency table should look like this:
# 
# ||protected|not protected|
# |-|-|-|
# |Mammal|?|?|
# |Bird|?|?|
# 
# Create a table called `contingency` and fill it in with the correct numbers

# In[28]:


contingency = [[30, 146],
               [75, 413]]


# In order to perform our chi square test, we'll need to import the correct function from scipy.  Past the following code and run it:
# ```py
# from scipy.stats import chi2_contingency
# ```

# In[29]:


from scipy.stats import chi2_contingency


# Now run `chi2_contingency` with `contingency`.

# In[30]:


_, pvalue, _, _, = chi2_contingency(contingency)
print pvalue


# In[31]:


# Conclusion p-value: as the pvalue is greater than 0.05, the null hypothesis is not rejected, that is to say that species in
# category `Mammal` are NOT more likely to be endangered than species in category `Bird`


# It looks like this difference isn't significant!
# 
# Let's test another.  Is the difference between `Reptile` and `Mammal` significant?

# In[32]:


contingency2 = [[30, 146],
                 [5, 73]]
_, pvalue_mammal_reptile, _, _, = chi2_contingency(contingency2)
print "P-value of", pvalue_mammal_reptile, "for 'Mammal' and 'Reptile'"


# In[33]:


# Conclusion p-value: as the pvalue is smaller than 0.05, the null hypothesis is rejected, that is to say that species in
# category `Mammal` are more likely to be endangered than species in category `Reptile`


# Yes! It looks like there is a significant difference between `Reptile` and `Mammal`!

# ### Step 5: Additional significance tests

# In[34]:


# Perform additional Chi-2 tests for all variable combinations

# Independence 'Amphibian' & 'Bird'
contingency3 = [[7, 72],
                [75, 413]]
_, pvalue_amphibian_bird, _, _, = chi2_contingency(contingency3)
print "P-value of", pvalue_amphibian_bird, "for 'Amphibian' and 'Bird'"

# Independence 'Amphibian' & 'Fish'
contingency4 = [[7, 72],
                [11, 115]]
_, pvalue_amphibian_fish, _, _, = chi2_contingency(contingency4)
print "P-value of", pvalue_amphibian_fish, "for 'Amphibian' and 'Fish'"

# Independence 'Amphibian' & 'Mammal'
contingency5 = [[7, 72],
                [30, 146]]
_, pvalue_amphibian_mammal, _, _, = chi2_contingency(contingency5)
print "P-value of", pvalue_amphibian_mammal, "for 'Amphibian' and 'Mammal'"

# Independence 'Amphibian' & 'Reptile' 
contingency6 = [[7, 72],
                [5, 73]]
_, pvalue_amphibian_reptile, _, _, = chi2_contingency(contingency6)
print "P-value of", pvalue_amphibian_reptile, "for 'Amphibian' and 'Reptile'"

# Independence 'Bird' & 'Fish'
contingency7 = [[75, 413],
                [11, 115]]
_, pvalue_bird_fish, _, _, = chi2_contingency(contingency7)
print "P-value of", pvalue_bird_fish, "for 'Bird' and 'Fish'"

# Independence 'Bird' & 'Reptile'
contingency8 = [[75, 413],
                [5, 73]]
_, pvalue_bird_reptile, _, _, = chi2_contingency(contingency8)
print "P-value of", pvalue_bird_reptile, "for 'Bird' and 'Reptile'"

# Independence 'Fish' & 'Mammal'
contingency9 =  [[11, 115],
                 [30, 146]]
_, pvalue_fish_mammal, _, _, = chi2_contingency(contingency9)
print "P-value of", pvalue_fish_mammal, "for 'Fish' and 'Mammal'"

# Independence 'Fish' & 'Reptile'
contingency10 = [[11, 115],
                 [5, 73]]
_, pvalue_fish_reptile, _, _, = chi2_contingency(contingency10)
print "P-value of", pvalue_fish_reptile, "for 'Fish' and 'Reptile'"


# In[35]:


# Create a new DataFrame to consolidate all p-values
p_values_table = pd.DataFrame({"amphibian": [np.nan, pvalue_amphibian_bird, pvalue_amphibian_fish, pvalue_amphibian_mammal, pvalue_amphibian_reptile],
                              "bird": [pvalue_amphibian_bird, np.nan, pvalue_bird_fish, pvalue, pvalue_bird_reptile],
                              "fish": [pvalue_amphibian_fish, pvalue_bird_fish, np.nan, pvalue_fish_mammal, pvalue_fish_reptile],
                              "mammal": [pvalue_amphibian_mammal, pvalue, pvalue_fish_mammal, np.nan, pvalue_mammal_reptile],
                              "reptile": [pvalue_amphibian_reptile, pvalue_bird_reptile, pvalue_fish_reptile, pvalue_mammal_reptile, np.nan]},
                             index = ["amphibian", "bird", "fish", "mammal", "reptile"])
p_values_table


# In[36]:


# Create a new DataFrame by replacing p-values by degree of significance
significance_table = p_values_table.applymap(lambda x: "significant" if x < 0.05 else "not significant")
significance_table


# # Step 6

# Conservationists have been recording sightings of different species at several national parks for the past 7 days.  They've saved sent you their observations in a file called `observations.csv`.  Load `observations.csv` into a variable called `observations`, then use `head` to view the data.

# In[37]:


# Load data from 'observations.csv'
observations = pd.read_csv('observations.csv')
observations.head()


# Some scientists are studying the number of sheep sightings at different national parks.  There are several different scientific names for different types of sheep.  We'd like to know which rows of `species` are referring to sheep.  Notice that the following code will tell us whether or not a word occurs in a string:

# In[38]:


# Does "Sheep" occur in this string?
str1 = 'This string contains Sheep'
'Sheep' in str1


# In[39]:


# Does "Sheep" occur in this string?
str2 = 'This string contains Cows'
'Sheep' in str2


# Use `apply` and a `lambda` function to create a new column in `species` called `is_sheep` which is `True` if the `common_names` contains `'Sheep'`, and `False` otherwise.

# In[40]:


# Create a new column 'is_sheep' to identify all sheep species
species['is_sheep'] = species.common_names.apply(lambda x: 'Sheep' in x)
species.head()


# Select the rows of `species` where `is_sheep` is `True` and examine the results.

# In[41]:


# Select a subset which contains 'sheep' species
species[species.is_sheep == True]


# Many of the results are actually plants.  Select the rows of `species` where `is_sheep` is `True` and `category` is `Mammal`.  Save the results to the variable `sheep_species`.

# In[42]:


# Select a subset which only contains 'sheep' that are 'Mammals'
sheep_species = species[(species.is_sheep == True) & (species.category == "Mammal")]
sheep_species


# Now merge `sheep_species` with `observations` to get a DataFrame with observations of sheep.  Save this DataFrame as `sheep_observations`.

# In[43]:


# Merge information from 'species' with 'observations' to get observations of sheep
sheep_observations = pd.merge(sheep_species, observations)


# How many total sheep observations (across all three species) were made at each national park?  Use `groupby` to get the `sum` of `observations` for each `park_name`.  Save your answer to `obs_by_park`.
# 
# This is the total number of sheep observed in each park over the past 7 days.

# In[44]:


# Return the weekly observations of sheep in each park
obs_by_park = sheep_observations.groupby('park_name').observations.sum().reset_index()
obs_by_park


# Create a bar chart showing the different number of observations per week at each park.
# 
# 1. Start by creating a wide figure with `figsize=(16, 4)`
# 1. Start by creating an axes object called `ax` using `plt.subplot`.
# 2. Create a bar chart whose heights are equal to `observations` column of `obs_by_park`.
# 3. Create an x-tick for each of the bars.
# 4. Label each x-tick with the label from `park_name` in `obs_by_park`
# 5. Label the y-axis `Number of Observations`
# 6. Title the graph `Observations of Sheep per Week`
# 7. Plot the grap using `plt.show()`

# In[45]:


# Create a bar chart to display the number of weekly observations of sheep in each park
plt.figure(figsize=(16, 4))
ax = plt.subplot()
plt.bar(range(len(obs_by_park)), obs_by_park.observations.values, color="tan")

# add some text for labels, title and ticks
ax.set_xticks(range(len(obs_by_park)))
ax.set_xticklabels(obs_by_park.park_name.values)
ax.set_ylim([0, 600])
plt.ylabel('Number of Observations')
plt.title('Observations of Sheep per Week')

# attach a text label above each bar displaying its heigth
for i in obs_by_park.index:
    ax.text(i, obs_by_park.at[i, 'observations']*1.05, obs_by_park.at[i, 'observations'], size=12, ha='center', va='bottom')

plt.show()


# Our scientists know that 15% of sheep at Bryce National Park have foot and mouth disease.  Park rangers at Yellowstone National Park have been running a program to reduce the rate of foot and mouth disease at that park.  The scientists want to test whether or not this program is working.  They want to be able to detect reductions of at least 5 percentage point.  For instance, if 10% of sheep in Yellowstone have foot and mouth disease, they'd like to be able to know this, with confidence.
# 
# Use the sample size calculator at <a href="https://www.optimizely.com/sample-size-calculator/">Optimizely</a> to calculate the number of sheep that they would need to observe from each park.  Use the default level of significance (90%).
# 
# Remember that "Minimum Detectable Effect" is a percent of the baseline.

# In[46]:


# The scientists want to run an A/B test to determine if the program led at Yellowstone National Park is working. In order to
# determine the sample size necessary for the A/B test, we need:
#   1) the baseline conversion rate,
#   2) the minimum detectable effect and
#   3) the statistical significance


# In[47]:


baseline_conversion_rate = 15


# In[48]:


minimum_detetacle_effect = 100 * (15 - 10) / 15
minimum_detetacle_effect


# In[49]:


stastistical_significance = 90


# In[50]:


sample_size = 520
# Using a sample size calculator, we need to observe 520 sheep in each park to run the A/B test.


# How many weeks would you need to observe sheep at Bryce National Park in order to observe enough sheep?  How many weeks would you need to observe at Yellowstone National Park to observe enough sheep?

# In[51]:


weeks_test_bryce = sample_size / 250
weeks_test_yellowstone = sample_size / 507


# In[52]:


print "We need observe sheep during", weeks_test_bryce, "weeks at Bryce National Park and", weeks_test_yellowstone, "week at Yellowstone National Park to observe enough sheep to run the A/B test."


# ### Step 6: Further analysis and visualization for 'observations'

# In[53]:


# Return the number of species observed in the national parks
observations.scientific_name.nunique()
# it's the same number than the number of species in 'species.csv'


# In[54]:


# Return the number of total observations in the national parks
observations.observations.sum()


# In[55]:


# Return the most weekly observed species for all parks combined with the park name
observations.loc[observations['observations'].idxmax()]


# In[56]:


# Return the least weekly observed species for all parks combined with the park name
observations.loc[observations['observations'].idxmin()]


# In[57]:


# Return the number of total observations in each national park
observations.groupby('park_name').observations.sum()


# In[58]:


# Merge 'observations' and 'species' to cross information on species and observations in each park
obs_by_species_parks = observations.groupby(['scientific_name', 'park_name']).observations.sum().reset_index()
obs_merged = pd.merge(obs_by_species_parks, species).drop_duplicates(subset={'scientific_name', 'park_name'}, keep='first')


# In[59]:


# Create a pivot table to return the observations in each category in each park
obs_by_category_parks = obs_merged.groupby(['park_name', 'category']).observations.sum().reset_index()
obs_pivot = obs_by_category_parks.pivot(columns='park_name',
                                       index='category', 
                                       values='observations').reset_index()
obs_pivot


# In[60]:


# Create a Top10 of the most observed species for all parks combined
top10 = obs_merged.groupby(['category', 'scientific_name', 'common_names'])    .observations.sum().reset_index()    .sort_values(by='observations', ascending=False)    .head(10)    .reset_index(drop=True)
top10


# In[61]:


# Create a bar chart to display the top10 observed species
plt.figure(figsize=(10, 5))
ax = plt.subplot()
plt.barh(range(len(top10)), top10.observations.values, color='lightgrey', align='center')
plt.gca().invert_yaxis()

# add labels, title and ticks
ax.set_yticks(range(len(top10)))
ax.set_yticklabels(top10.common_names.values)
plt.xlabel('Common names of Species')
plt.title('Top10 of the Most Observed Species in the 4 Parks')

plt.show()

